#include<stdio.h>
int main()
{
    int age;
    float cgpa;
    char grade;
    
    int *pAge;
    float *pCgpa;
    char *pGrade;

    pAge = &age;
    pCgpa = &cgpa;
    pGrade = &grade;

    printf("Enter age: ", age);
    scanf("%d", &age);
    printf("Enter cgpa: ");
    scanf("%f", &cgpa);
    printf("Enter grade: ");
    scanf(" %c", &grade);  

    printf("age = %d\t via pointer = %d\t &age = %p\t pAge = %p\n", age,*pAge, &age,pAge);
    printf("cgpa = %f\t via pointer = %f\t &cgpa = %p\t pCgpa = %p\n", cgpa,*pCgpa,&cgpa,pCgpa);
    printf("grade =%c\t via pointer = %c\t &grade = %p\t pGrade = %p\n", grade,*pGrade,&grade,pGrade);

    printf("Address of pAge = %p\n", &pAge);
    printf("Address of pCgpa = %p\n", &pCgpa); 
    printf("Address of pGrade = %p\n", &pGrade);

    printf("After changing values using pointers:\n");
    *pAge = age + 1 ;
    *pCgpa = cgpa + 0.25;
    *pGrade = grade + 1;

    printf("age = %d\t grade = %c\t cgpa = %f\n", *pAge, *pGrade, *pCgpa);


    return 0;
}
